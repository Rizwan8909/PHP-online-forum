<?php 
    include '_dbConnection.php';
    $showError = "false";
    $showAlert = false;
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $user_email = $_POST['signupEmail'];
        $password = $_POST['signupPassword'];
        $cPassword = $_POST['signupcPassword'];
       
        // Checking weather user already exists or not
        $exitsSql = "SELECT * FROM `users` WHERE user_email = '$user_email'";
        $result = mysqli_query($conn, $exitsSql);
        $num = mysqli_num_rows($result);
        if($num>0){
            $showError = "Email already exists";
            echo $showError;
        }

        else{
            //    Inserstion in database
                if($password == $cPassword){
                    // Password hashing
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "INSERT INTO `users` (`user_email`, `user_password`, `time`) VALUES ('$user_email', '$hash', current_timestamp());";
                    $result = mysqli_query($conn, $sql);
                    if($result){
                        $showAlert = true;
                        header("location: /Forum/index.php?signupSuccess=true");
                        exit();
                    }
                    else{
                        $showError = "Passwords do not match";
                        header("location: /Forum/index.php/signupSuccess=false&error=$showError");
                    }
                }
            }

            header("location: /Forum/index.php/signupSuccess=false&error=$showError");
        }
?>