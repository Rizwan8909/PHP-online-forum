<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $databasename = 'forum';

    $conn = mysqli_connect($servername, $username, $password, $databasename);

    if(!$conn){
        die("Cannot connect to database due to --> " . mysqli_connect_error());
    }
   
?>