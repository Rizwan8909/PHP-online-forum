<?php
      include '_dbConnection.php';

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
          $user_email = $_POST['loginEmail'];
          $password = $_POST['loginPassword'];

          $sql = "SELECT * FROM `users` WHERE `user_email` = '$user_email'";
          $result = mysqli_query($conn, $sql);
          $num = mysqli_num_rows($result);

        //   Checking the existance of useremail
        if($num == 1){
            $row = mysqli_fetch_assoc($result);

            // Verifying password
            if(password_verify($password, $row['user_password'])){
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['useremail'] = $user_email; 
                echo "Logged in as " . $user_email;       
            }
            header("location: /Forum/index.php");     
        }
        header("location: /Forum/index.php");
      }
?>