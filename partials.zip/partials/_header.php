

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm" style="background-color: #FF5678;">
  <a class="navbar-brand" href="#">F4Forum</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/Forum/index.php">Home <span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item active">
        <a class="nav-link" href="#">About <span class="sr-only">(current)</span></a>
      </li>
      
      
    <!-- Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Categories
        </a>
        <div class="dropdown-menu rounded-0" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Python</a>
          <div class="dropdown-divider"></div>

          <a class="dropdown-item" href="#">Javascript</a>
          <div class="dropdown-divider"></div>

          <a class="dropdown-item" href="#">.Net</a>
        </div>
      </li>
   
      <li class="nav-item active">
        <a class="nav-link" href="/Forum/contact.php">Contact</span></a>
      </li>
      
    </ul>
    <div class="my-2 my-lg-0">
      <!-- <input class="form-control mr-sm-2 rounded-0" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0 ml-1 rounded-0" type="submit">Search</button> -->
      <button class="btn btn-outline-light my-2 my-sm-0 ml-1 rounded-0" data-toggle="modal" data-target="#loginModal" >Login</button>
      <button class="btn btn-outline-light my-2 my-sm-0 ml-1 rounded-0" data-toggle="modal" data-target="#signupModal"">Signup</button>
    </div>
  </div>
</nav>

<!-- Login/signup modal -->
<?php include 'partials/_modalLogin.php'; ?>
<?php include 'partials/_modalSignup.php'; ?>