<?php
    session_start();
    session_unset();
    echo "Logging you out ...";
    session_destroy();
    header("location: /Forum/index.php");
?>
