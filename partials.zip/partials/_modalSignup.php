
<!-- Modal -->
<div class="modal" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered rounded-0">
        <div class="modal-content">
            <div class="modal-header text-white" style="background-color: #FF5678;">
                <h5 class="modal-title" id="signupModalLabel">Sign up</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <img src="images/sign.gif" alt="" style="width: 50%; margin:0 auto; margin-top: 10px">
            
            <form class="p-4">
                <div class="modal-body">

                    <div class="form-group">
                        <input type="text" class="form-control rounded-0 border-dark" id="username" name="username" placeholder="Username">
                        <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control rounded-0 border-dark" id="password" name="password" placeholder="Password">
                        <!-- <small id="emailHelp" class="form-text text-muted">Forgot your password?</small> -->
                    </div>

                    <div class="form-group">
                        <input type="password" class="form-control rounded-0 border-dark" id="cpassword" name="cpassword" placeholder="Confirm Password">
                        <small id="emailHelp" class="form-text text-muted">Make sure your type the same password.</small>
                    </div>
                   
                    <!-- <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input rounded-0" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                        
                    </div> -->
                    <button type="submit" class="btn rounded-0 btn-block text-white mb-2" style="background-color: #FF5678;">Sign-up</button>

                </div>
            </form>
        </div>
    </div>
</div>